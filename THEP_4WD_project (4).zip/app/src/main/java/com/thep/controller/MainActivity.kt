package com.thep.controller

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.*
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.os.*
import android.provider.Settings
import android.speech.*
import android.view.*
import android.widget.*
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID
import java.util.concurrent.Executors
import kotlin.math.*

object Neon {
    lateinit var font: Typeface; lateinit var thai: Typeface
    fun init(c: Context) {
        font = try { Typeface.createFromAsset(c.assets, "fonts/Orbitron-Black.ttf") } catch (e: Exception) { Typeface.create(Typeface.MONOSPACE, Typeface.BOLD) }
        thai = try { Typeface.createFromAsset(c.assets, "fonts/Kanit-Black.ttf") } catch (e: Exception) { Typeface.DEFAULT_BOLD }
    }
    fun t() = (SystemClock.uptimeMillis() % 1_000_000L) / 1000f
    fun hue(t: Float, off: Float = 0f) = Color.HSVToColor(floatArrayOf(((t * 120f + off) % 360f + 360f) % 360f, 1f, 1f))
}

// ---------- Bluetooth + auto reconnect ----------
class BtLink(val onLine: (String) -> Unit, val onState: (Boolean, String) -> Unit) {
    private val uuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private val tx = Executors.newSingleThreadExecutor()
    @Volatile private var sock: BluetoothSocket? = null
    @Volatile private var out: OutputStream? = null
    @Volatile var connected = false
    @Volatile private var want = false

    @SuppressLint("MissingPermission")
    fun connect(d: BluetoothDevice) {
        want = true
        Thread {
            while (want) {
                try {
                    val s = d.createRfcommSocketToServiceRecord(uuid); s.connect()
                    sock = s; out = s.outputStream; connected = true
                    onState(true, d.name ?: "THEP"); read(s.inputStream)
                } catch (_: Exception) {}
                connected = false; out = null
                try { sock?.close() } catch (_: Exception) {}
                if (want) { onState(false, "RECONNECTING..."); SystemClock.sleep(700) }
            }
        }.start()
    }
    private fun read(i: InputStream) {
        val sb = StringBuilder(); val b = ByteArray(256)
        while (true) {
            val n = i.read(b); if (n < 0) return
            for (k in 0 until n) {
                val c = b[k].toInt().toChar()
                if (c == '\n') { onLine(sb.toString()); sb.setLength(0) } else if (c != '\r' && sb.length < 64) sb.append(c)
            }
        }
    }
    fun send(s: String) {
        val o = out ?: return
        tx.execute { try { o.write((s + "\n").toByteArray()); o.flush() } catch (_: Exception) { try { sock?.close() } catch (_: Exception) {} } }
    }
    fun disconnect() { send("S"); want = false; tx.execute { try { sock?.close() } catch (_: Exception) {} } }
}

// ---------- RGB background ----------
class NeonFrame(c: Context) : FrameLayout(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    init { setWillNotDraw(false); setBackgroundColor(Color.rgb(4, 4, 12)) }
    override fun onDraw(cv: Canvas) {
        val t = Neon.t(); val w = width.toFloat(); val h = height.toFloat()
        p.shader = null; p.style = Paint.Style.STROKE; p.strokeWidth = 1f; p.color = Color.argb(30, 0, 255, 255)
        val g = 46f; var x = 0f; while (x < w) { cv.drawLine(x, 0f, x, h, p); x += g }
        var y = (t * 30f) % g; while (y < h) { cv.drawLine(0f, y, w, y, p); y += g }
        val cols = intArrayOf(Neon.hue(t), Neon.hue(t, 90f), Neon.hue(t, 180f), Neon.hue(t, 270f), Neon.hue(t))
        p.shader = SweepGradient(w / 2, h / 2, cols, null)
        p.strokeWidth = 18f; p.alpha = 60; cv.drawRoundRect(8f, 8f, w - 8f, h - 8f, 34f, 34f, p)
        p.strokeWidth = 5f; p.alpha = 255; cv.drawRoundRect(8f, 8f, w - 8f, h - 8f, 34f, 34f, p)
        p.shader = null
        postInvalidateOnAnimation()
    }
}

// ---------- หัวข้อ RGB ----------
class RgbTitle(c: Context, private val big: String, private val small: String) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    override fun onMeasure(a: Int, b: Int) = setMeasuredDimension(MeasureSpec.getSize(a), (resources.displayMetrics.density * 140).toInt())
    override fun onDraw(cv: Canvas) {
        val t = Neon.t(); val w = width.toFloat(); val h = height.toFloat(); val cx = w / 2; val y = h * 0.6f
        p.typeface = Neon.thai; p.textSize = min(w / 7f, h * 0.5f)
        p.shader = null; p.color = Neon.hue(t); p.setShadowLayer(30f, 0f, 0f, Neon.hue(t)); cv.drawText(big, cx, y, p); p.clearShadowLayer()
        val s = (t * 400f) % (2 * w)
        p.shader = LinearGradient(s - w, 0f, s, 0f, intArrayOf(Color.RED, Color.YELLOW, Color.GREEN, Color.CYAN, Color.BLUE, Color.MAGENTA, Color.RED), null, Shader.TileMode.MIRROR)
        cv.drawText(big, cx, y, p); p.shader = null
        if ((t * 10).toInt() % 17 == 0) {
            p.color = Color.argb(170, 255, 0, 90); cv.drawText(big, cx + 7, y, p)
            p.color = Color.argb(170, 0, 255, 255); cv.drawText(big, cx - 7, y, p)
        }
        p.typeface = Neon.font; p.textSize = h * 0.12f; p.color = Color.CYAN; p.letterSpacing = 0.25f
        cv.drawText(small + if ((t * 2).toInt() % 2 == 0) "_" else " ", cx, h * 0.9f, p); p.letterSpacing = 0f
        postInvalidateOnAnimation()
    }
}

// ---------- ปุ่มนีออน ----------
class NeonBtn(c: Context, var label: String, private val hueOff: Float = 0f, private val instant: Boolean = true, private val onTap: () -> Unit) : View(c) {
    var color: Int? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG); private var down = false
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { down = true; performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY); if (instant) onTap() }
            MotionEvent.ACTION_UP -> { if (down && !instant && e.x in 0f..width.toFloat() && e.y in 0f..height.toFloat()) onTap(); down = false }
            MotionEvent.ACTION_CANCEL -> down = false
        }
        return true
    }
    override fun onDraw(cv: Canvas) {
        val t = Neon.t(); val w = width.toFloat(); val h = height.toFloat(); val r = h * 0.3f; val i = 8f
        val col = color ?: Neon.hue(t, hueOff)
        p.style = Paint.Style.FILL; p.color = col; p.alpha = if (down) 130 else 40
        cv.drawRoundRect(i, i, w - i, h - i, r, r, p)
        p.style = Paint.Style.STROKE; p.alpha = 70; p.strokeWidth = 14f; cv.drawRoundRect(i, i, w - i, h - i, r, r, p)
        p.alpha = 255; p.strokeWidth = 3f; cv.drawRoundRect(i, i, w - i, h - i, r, r, p)
        p.style = Paint.Style.FILL; p.color = Color.WHITE; p.textAlign = Paint.Align.CENTER; p.typeface = Neon.thai
        p.textSize = min(h * 0.36f, w / (label.length * 0.6f + 1f))
        p.setShadowLayer(16f, 0f, 0f, col)
        cv.drawText(label, w / 2, h / 2 - (p.descent() + p.ascent()) / 2, p); p.clearShadowLayer()
        postInvalidateOnAnimation()
    }
}

// ---------- จอยพวงมาลัย / คันเร่ง ----------
class Stick(c: Context, private val vertical: Boolean, private val name: String) : View(c) {
    var v = 0f; private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private fun rad() = min(width, height) * 0.22f
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                v = if (vertical) (height / 2f - e.y) / (height / 2f - rad()) else (e.x - width / 2f) / (width / 2f - rad())
                v = v.coerceIn(-1f, 1f); if (abs(v) < 0.07f) v = 0f
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v = 0f
        }
        return true
    }
    override fun onDraw(cv: Canvas) {
        val t = Neon.t(); val w = width.toFloat(); val h = height.toFloat(); val r = rad(); val col = Neon.hue(t, if (vertical) 180f else 0f)
        val l = if (vertical) w / 2 - r * 1.1f else 10f; val rt = if (vertical) w / 2 + r * 1.1f else w - 10f
        val tp = if (vertical) 10f else h / 2 - r * 1.1f; val bt = if (vertical) h - 10f else h / 2 + r * 1.1f
        p.shader = null; p.style = Paint.Style.FILL; p.color = Color.argb(35, 0, 255, 255); cv.drawRoundRect(l, tp, rt, bt, r, r, p)
        p.style = Paint.Style.STROKE; p.color = col; p.alpha = 60; p.strokeWidth = 16f; cv.drawRoundRect(l, tp, rt, bt, r, r, p)
        p.alpha = 255; p.strokeWidth = 3f; cv.drawRoundRect(l, tp, rt, bt, r, r, p)
        p.color = Color.argb(90, 255, 255, 255)
        if (vertical) cv.drawLine(l + 20, h / 2, rt - 20, h / 2, p) else cv.drawLine(w / 2, tp + 20, w / 2, bt - 20, p)
        val cx = if (vertical) w / 2 else w / 2 + v * (w / 2 - r); val cy = if (vertical) h / 2 - v * (h / 2 - r) else h / 2
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(cx, cy, r * 1.3f, intArrayOf(Color.WHITE, col, Color.TRANSPARENT), floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP)
        cv.drawCircle(cx, cy, r * 1.3f, p); p.shader = null
        p.color = Color.WHITE; p.textAlign = Paint.Align.CENTER; p.typeface = Neon.font; p.textSize = r * 0.32f
        cv.drawText("$name ${(v * 100).roundToInt()}%", w / 2, if (vertical) h - 24f else tp - 14f, p)
        postInvalidateOnAnimation()
    }
}

// ---------- HUD กลางจอ ----------
class Hud(c: Context) : View(c) {
    var online = false; var status = "CONNECTING..."; var mode = 1; var voice = ""; var l = 0; var r = 0
    private var msg = ""; private var msgUntil = 0L
    fun flash(m: String) { msg = m; msgUntil = SystemClock.uptimeMillis() + 1200 }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    override fun onDraw(cv: Canvas) {
        val t = Neon.t(); val w = width.toFloat(); val h = height.toFloat(); val cx = w / 2
        p.typeface = Neon.thai; p.textSize = h * 0.12f
        p.shader = LinearGradient(0f, 0f, w, 0f, intArrayOf(Neon.hue(t), Neon.hue(t, 120f), Neon.hue(t, 240f)), null, Shader.TileMode.CLAMP)
        cv.drawText("โปรเจ็คเด็กคอม", cx, h * 0.13f, p); p.shader = null
        p.typeface = Neon.font; p.textSize = h * 0.055f
        p.color = if (online) Color.rgb(0, 255, 140) else if ((t * 3).toInt() % 2 == 0) Color.rgb(255, 50, 70) else Color.DKGRAY
        cv.drawText("● $status", cx, h * 0.22f, p)
        fun bar(x: Float, v: Int, n: String) {
            val top = h * 0.28f; val bot = h * 0.76f; val mid = (top + bot) / 2; val bw = w * 0.13f
            p.style = Paint.Style.STROKE; p.strokeWidth = 3f; p.color = Color.argb(140, 0, 255, 255)
            cv.drawRoundRect(x - bw / 2, top, x + bw / 2, bot, 12f, 12f, p)
            p.style = Paint.Style.FILL; val y = mid - v / 100f * (mid - top)
            p.color = if (v >= 0) Neon.hue(t, 90f) else Neon.hue(t, 300f)
            cv.drawRoundRect(x - bw / 2 + 5, min(y, mid), x + bw / 2 - 5, max(y, mid), 8f, 8f, p)
            p.color = Color.WHITE; cv.drawText("$n $v", x, bot + h * 0.07f, p)
        }
        bar(w * 0.3f, l, "L"); bar(w * 0.7f, r, "R")
        p.textSize = h * 0.07f; p.color = if (mode == 1) Color.rgb(255, 40, 90) else Color.rgb(0, 255, 120)
        p.setShadowLayer(20f, 0f, 0f, p.color); cv.drawText(if (mode == 1) "FULL POWER" else "ECO MODE", cx, h * 0.53f, p); p.clearShadowLayer()
        p.textSize = h * 0.05f; p.color = Color.CYAN; p.typeface = Neon.thai
        cv.drawText(if (voice.isEmpty()) "" else "MIC: $voice", cx, h * 0.95f, p)
        if (SystemClock.uptimeMillis() < msgUntil) {
            p.textSize = h * 0.11f; p.color = Color.YELLOW; p.setShadowLayer(25f, 0f, 0f, Color.YELLOW)
            cv.drawText(msg, cx, h * 0.45f, p); p.clearShadowLayer()
        }
        postInvalidateOnAnimation()
    }
}

// ---------- Activity ----------
class MainActivity : Activity() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var link: BtLink
    private var hud: Hud? = null; private var steer: Stick? = null; private var thr: Stick? = null
    private var modeBtn: NeonBtn? = null; private var micBtn: NeonBtn? = null; private var durBtn: NeonBtn? = null
    private var lastL = 0; private var lastR = 0; private var lastSend = 0L
    private var mode = 1; private var invL = 0; private var invR = 0; private var swap = 0; private var gl = 100; private var gr = 100
    private val durs = intArrayOf(1500, 3000, 0); private val durNames = arrayOf("1.5s", "3s", "ค้าง"); private var durIdx = 0
    private var sr: SpeechRecognizer? = null; private var listening = false; private var heardEnd = 0
    private val M = ViewGroup.LayoutParams.MATCH_PARENT
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun lp(w: Int, h: Int, wt: Float = 0f) = LinearLayout.LayoutParams(w, h, wt).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b); Neon.init(this)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        link = BtLink({ l -> ui.post { onLine(l) } }, { ok, m -> ui.post { hud?.online = ok; hud?.status = if (ok) "ONLINE // $m" else m; if (ok) link.send("G") } })
        val need = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 31) need += Manifest.permission.BLUETOOTH_CONNECT
        requestPermissions(need.toTypedArray(), 1)
        showConnect(); ui.post(tick)
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, g: IntArray) { super.onRequestPermissionsResult(c, p, g); if (hud == null) showConnect() }

    override fun onWindowFocusChanged(f: Boolean) {
        super.onWindowFocusChanged(f)
        @Suppress("DEPRECATION")
        if (f) window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
    }

    @SuppressLint("MissingPermission")
    private fun showConnect() {
        stopVoice(); hud = null; steer = null; thr = null
        val root = NeonFrame(this)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(24), dp(10), dp(24), dp(10)) }
        col.addView(RgbTitle(this, "โปรเจ็คเด็กคอม", "THEP 4WD // CONTROL SYSTEM v7"))
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(ScrollView(this).apply { addView(list) }, lp(M, 0, 1f))
        val row = LinearLayout(this)
        row.addView(NeonBtn(this, "รีเฟรช", 200f, false) { fill(list) }, lp(0, dp(56), 1f))
        row.addView(NeonBtn(this, "จับคู่ BLUETOOTH", 300f, false) { startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }, lp(0, dp(56), 1f))
        col.addView(row)
        root.addView(col); setContentView(root); fill(list)
    }

    @SuppressLint("MissingPermission")
    private fun fill(list: LinearLayout) {
        list.removeAllViews()
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            list.addView(NeonBtn(this, "แตะเพื่ออนุญาต BLUETOOTH", 0f, false) { requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 1) }, lp(M, dp(64))); return
        }
        val ad = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
        if (ad == null || !ad.isEnabled) { list.addView(NeonBtn(this, "เปิด BLUETOOTH ก่อน", 0f, false) { fill(list) }, lp(M, dp(64))); return }
        val devs = ad.bondedDevices.sortedByDescending { (it.name ?: "").contains("THEP") }
        if (devs.isEmpty()) list.addView(NeonBtn(this, "ยังไม่ได้จับคู่ THEP_4WD", 0f, false) {}, lp(M, dp(64)))
        devs.forEachIndexed { i, d ->
            list.addView(NeonBtn(this, "▶ ${d.name ?: "?"} // ${d.address}", i * 50f, false) { link.connect(d); showDrive() }, lp(M, dp(64)))
        }
    }

    private fun showDrive() {
        val root = NeonFrame(this)
        val h = LinearLayout(this).apply { setPadding(dp(14), dp(14), dp(14), dp(14)) }
        steer = Stick(this, false, "STEER"); thr = Stick(this, true, "GAS")
        val mid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        hud = Hud(this).also { it.mode = mode }
        mid.addView(hud, lp(M, 0, 1f))
        val r1 = LinearLayout(this); val r2 = LinearLayout(this)
        val mb = NeonBtn(this, if (mode == 1) "FULL" else "ECO", 0f) { link.send("E,${1 - mode}") }
        val mc = NeonBtn(this, "MIC OFF", 120f) { if (listening) stopVoice() else startVoice() }
        val db = NeonBtn(this, "เสียง ${durNames[durIdx]}", 240f) { durIdx = (durIdx + 1) % 3; durBtn?.label = "เสียง ${durNames[durIdx]}" }
        modeBtn = mb; micBtn = mc; durBtn = db
        r1.addView(mb, lp(0, dp(50), 1f)); r1.addView(mc, lp(0, dp(50), 1f)); r1.addView(db, lp(0, dp(50), 1f))
        r2.addView(NeonBtn(this, "SETUP", 60f) { showSetup() }, lp(0, dp(50), 1f))
        r2.addView(NeonBtn(this, "■ STOP", 0f) { link.send("S"); hud?.flash("STOP") }.apply { color = Color.rgb(255, 30, 60) }, lp(0, dp(50), 1.6f))
        r2.addView(NeonBtn(this, "ออก", 300f, false) { link.disconnect(); showConnect() }, lp(0, dp(50), 1f))
        mid.addView(r1); mid.addView(r2)
        h.addView(steer, lp(0, M, 1.15f)); h.addView(mid, lp(0, M, 1.3f)); h.addView(thr, lp(0, M, 0.7f))
        root.addView(h); setContentView(root)
    }

    private fun showSetup() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(18)) }
        val tip = TextView(this).apply {
            setTextColor(Color.CYAN); typeface = Neon.thai; textSize = 13f
            text = "1) TEST ล้อซ้าย: ถ้าล้อขวาหมุน กด สลับ ซ้าย/ขวา\n2) ถ้าล้อหมุนถอยหลัง กด กลับทิศ ฝั่งนั้น\n3) รถวิ่งเบี้ยว ใช้ปุ่มแก้เบี้ยว"
        }
        box.addView(tip)
        fun row(vararg b: NeonBtn) { val r = LinearLayout(this); b.forEach { r.addView(it, lp(0, dp(52), 1f)) }; box.addView(r) }
        row(NeonBtn(this, "TEST ล้อซ้าย", 0f) { link.send("T,0") }, NeonBtn(this, "TEST ล้อขวา", 60f) { link.send("T,1") })
        row(NeonBtn(this, "สลับ ซ้าย/ขวา", 120f) { link.send("W,${1 - swap}") })
        row(NeonBtn(this, "กลับทิศ ซ้าย", 180f) { link.send("C,0,${1 - invL}") }, NeonBtn(this, "กลับทิศ ขวา", 240f) { link.send("C,1,${1 - invR}") })
        row(
            NeonBtn(this, "แก้เบี้ยวซ้าย", 280f) { if (gl < 100) gl += 2 else gr = max(50, gr - 2); link.send("K,$gl,$gr") },
            NeonBtn(this, "แก้เบี้ยวขวา", 320f) { if (gr < 100) gr += 2 else gl = max(50, gl - 2); link.send("K,$gl,$gr") }
        )
        row(NeonBtn(this, "รีเซ็ตทั้งหมด", 0f, false) { link.send("X") }.apply { color = Color.rgb(255, 60, 60) })
        val frame = NeonFrame(this).apply { addView(ScrollView(this@MainActivity).apply { addView(box) }) }
        AlertDialog.Builder(this).setView(frame).show().window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
    }

    private val tick = object : Runnable {
        override fun run() {
            val s = steer; val t = thr
            if (s != null && t != null && link.connected) {
                val th = (t.v * abs(t.v) * 100).roundToInt(); val st = (s.v * abs(s.v) * 100).roundToInt()
                var l: Int; var r: Int
                if (abs(th) < 6) { l = st; r = -st } else { l = th + st; r = th - st }
                val m = max(abs(l), abs(r)); if (m > 100) { l = l * 100 / m; r = r * 100 / m }
                val now = SystemClock.uptimeMillis()
                if (l != lastL || r != lastR || ((l != 0 || r != 0) && now - lastSend >= 100)) {
                    link.send("M,$l,$r"); lastL = l; lastR = r; lastSend = now
                }
            }
            ui.postDelayed(this, 40)
        }
    }

    private fun onLine(s: String) {
        try {
            val p = s.split(',')
            when (p[0]) {
                "T" -> { hud?.l = p[1].toInt(); hud?.r = p[2].toInt(); if (p.size > 3) setMode(p[3].toInt()) }
                "CFG" -> { invL = p[1].toInt(); invR = p[2].toInt(); swap = p[3].toInt(); setMode(p[4].toInt()); gl = p[5].toInt(); gr = p[6].toInt() }
                "FS" -> hud?.flash("FAILSAFE")
                else -> {}
            }
        } catch (_: Exception) {}
    }

    private fun setMode(m: Int) { mode = m; hud?.mode = m; modeBtn?.label = if (m == 1) "FULL" else "ECO" }

    // ---------- คำสั่งเสียง: ฟังต่อเนื่อง ทำทันทีจาก partial result ----------
    private val words = listOf(
        "หยุด" to "S", "stop" to "S", "เบรก" to "S",
        "เดินหน้า" to "F", "หน้า" to "F", "ตรงไป" to "F", "forward" to "F",
        "ถอย" to "B", "หลัง" to "B", "back" to "B",
        "ซ้าย" to "L", "left" to "L", "ขวา" to "R", "right" to "R",
        "ประหยัด" to "E", "eco" to "E", "เต็ม" to "P", "เทอร์โบ" to "P", "turbo" to "P", "full" to "P"
    )

    private fun vIntent() = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "th-TH"); putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true); putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
    }

    private fun startVoice() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 2); return }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { hud?.flash("NO VOICE"); return }
        sr = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onPartialResults(b: Bundle?) = onSpeech(b)
                override fun onResults(b: Bundle?) { onSpeech(b); relisten(60) }
                override fun onError(e: Int) = relisten(if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 300 else 80)
                override fun onReadyForSpeech(p: Bundle?) { heardEnd = 0 }
                override fun onBeginningOfSpeech() { heardEnd = 0 }
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onEvent(t: Int, b: Bundle?) {}
            })
        }
        listening = true; micBtn?.label = "MIC ON"; micBtn?.color = Color.rgb(0, 255, 120); sr?.startListening(vIntent())
    }

    private fun relisten(d: Long) { if (listening) ui.postDelayed({ if (listening) { sr?.cancel(); sr?.startListening(vIntent()) } }, d) }

    private fun stopVoice() {
        listening = false; sr?.destroy(); sr = null
        micBtn?.label = "MIC OFF"; micBtn?.color = null; hud?.voice = ""
    }

    private fun onSpeech(b: Bundle?) {
        val txt = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.lowercase() ?: return
        hud?.voice = txt
        var bestE = -1; var cmd = ""
        for ((k, c) in words) { val i = txt.lastIndexOf(k); if (i >= 0 && i + k.length > bestE) { bestE = i + k.length; cmd = c } }
        if (bestE <= heardEnd) return
        heardEnd = bestE; voiceCmd(cmd)
    }

    private fun voiceCmd(c: String) {
        val d = durs[durIdx]; val turn = if (d == 0) 0 else 550
        when (c) {
            "S" -> link.send("S")
            "F" -> link.send("D,100,100,$d")
            "B" -> link.send("D,-100,-100,$d")
            "L" -> link.send("D,-85,85,$turn")
            "R" -> link.send("D,85,-85,$turn")
            "E" -> link.send("E,0")
            "P" -> link.send("E,1")
        }
        lastL = 0; lastR = 0
        hud?.flash(mapOf("S" to "STOP", "F" to "FORWARD", "B" to "BACK", "L" to "LEFT", "R" to "RIGHT", "E" to "ECO", "P" to "FULL POWER")[c] ?: "")
    }

    override fun onPause() { super.onPause(); link.send("S"); lastL = 0; lastR = 0; stopVoice() }
    override fun onDestroy() { ui.removeCallbacksAndMessages(null); link.disconnect(); super.onDestroy() }
}
