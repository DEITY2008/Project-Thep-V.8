plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.thep.controller"; compileSdk = 34
    defaultConfig {
        applicationId = "com.thep.controller"; minSdk = 24; targetSdk = 34
        versionCode = 7; versionName = "7.0"
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
