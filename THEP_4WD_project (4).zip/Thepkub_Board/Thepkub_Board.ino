// ===== THEP 4WD v7 — โปรเจ็คเด็กคอม (ESP32 + L298N) =====
#include <BluetoothSerial.h>
#include <Preferences.h>
BluetoothSerial BT; Preferences pref;

const int ENA = 25, IN1 = 26, IN2 = 27; // ช่อง A
const int ENB = 33, IN3 = 14, IN4 = 32; // ช่อง B
const int PWM_HZ = 1000, PWM_BITS = 8;

#if ESP_ARDUINO_VERSION_MAJOR >= 3
#define PWM_ATTACH(pin, ch) ledcAttach(pin, PWM_HZ, PWM_BITS)
#define PWM_WRITE(pin, ch, v) ledcWrite(pin, v)
#else
#define PWM_ATTACH(pin, ch) do { ledcSetup(ch, PWM_HZ, PWM_BITS); ledcAttachPin(pin, ch); } while (0)
#define PWM_WRITE(pin, ch, v) ledcWrite(ch, v)
#endif

// 0 = ECO ประหยัดพลังงาน, 1 = FULL ใช้พลังงานเต็ม
struct Mode { int maxPct, ramp, minDuty, kickMs, telMs; };
const Mode MODES[2] = { {60, 3, 70, 0, 400}, {100, 25, 85, 60, 120} };

uint8_t invL = 0, invR = 0, swapLR = 0, mode = 1, gainL = 100, gainR = 100;
int tgtL = 0, tgtR = 0, curL = 0, curR = 0;
uint32_t lastCmd = 0, lastStep = 0, lastTel = 0, runUntil = 0, kickL = 0, kickR = 0, brakeUntil = 0;
bool holdRun = false, fsSent = true;
int cacheA = 9999, cacheB = 9999;
char buf[48]; uint8_t blen = 0;

void hw(int en, int ch, int a, int b, int d, int &cache, bool brake) {
  int key = brake ? 1000 : d;
  if (key == cache) return; // ไม่เขียนซ้ำ = เร็วขึ้น
  cache = key;
  if (brake) { digitalWrite(a, HIGH); digitalWrite(b, HIGH); PWM_WRITE(en, ch, 255); return; }
  digitalWrite(a, d > 0); digitalWrite(b, d < 0); PWM_WRITE(en, ch, abs(d));
}

int toDuty(int v, int gain, bool inv, bool kick) {
  if (!v) return 0;
  const Mode &m = MODES[mode];
  int mag = abs(v) * m.maxPct / 100 * gain / 100;
  if (mag < 1) mag = 1;
  int d = kick ? 255 : map(mag, 1, 100, m.minDuty, 255);
  if (inv) v = -v;
  return v > 0 ? d : -d;
}

void applyOut(uint32_t now) {
  int dL = toDuty(curL, gainL, invL, (int32_t)(kickL - now) > 0);
  int dR = toDuty(curR, gainR, invR, (int32_t)(kickR - now) > 0);
  if (swapLR) { int t = dL; dL = dR; dR = t; }
  bool br = (int32_t)(brakeUntil - now) > 0;
  hw(ENA, 0, IN1, IN2, dL, cacheA, br);
  hw(ENB, 1, IN3, IN4, dR, cacheB, br);
}

void stopNow(bool brake) {
  tgtL = tgtR = curL = curR = 0; holdRun = false; runUntil = 0;
  if (brake) brakeUntil = millis() + 120;
  applyOut(millis());
}

void setTarget(long l, long r) {
  tgtL = constrain(l, -100, 100); tgtR = constrain(r, -100, 100); brakeUntil = 0;
}

void saveCfg() {
  pref.putUChar("il", invL); pref.putUChar("ir", invR); pref.putUChar("sw", swapLR);
  pref.putUChar("md", mode); pref.putUChar("gl", gainL); pref.putUChar("gr", gainR);
}

void sendCfg() { BT.printf("CFG,%d,%d,%d,%d,%d,%d\n", invL, invR, swapLR, mode, gainL, gainR); }

void runTimed(long l, long r, long ms, uint32_t now) { // คำสั่งเสียง: ทำทันที ไม่รอ ramp
  setTarget(l, r); curL = tgtL; curR = tgtR;
  if (MODES[mode].kickMs) kickL = kickR = now + MODES[mode].kickMs;
  holdRun = true; runUntil = ms > 0 ? now + ms : 0; lastCmd = now; fsSent = false;
}

void handle(char *s) {
  long v[4] = {0, 0, 0, 0}; int n = 0;
  char *p = strchr(s, ',');
  while (p && n < 4) { v[n++] = strtol(p + 1, &p, 10); if (*p != ',') p = nullptr; }
  uint32_t now = millis();
  switch (s[0]) {
    case 'M': if (n >= 2) { setTarget(v[0], v[1]); holdRun = false; runUntil = 0; lastCmd = now; fsSent = false; } break;
    case 'D': if (n >= 3) runTimed(v[0], v[1], v[2], now); break;
    case 'S': stopNow(true); break;
    case 'E': if (n >= 1) { mode = v[0] ? 1 : 0; saveCfg(); sendCfg(); } break;
    case 'W': swapLR = (n >= 1) ? (v[0] ? 1 : 0) : !swapLR; saveCfg(); sendCfg(); break;
    case 'C': if (n >= 2) { if (v[0] == 0) invL = v[1] ? 1 : 0; else invR = v[1] ? 1 : 0; saveCfg(); sendCfg(); } break;
    case 'K': if (n >= 2) { gainL = constrain(v[0], 50, 100); gainR = constrain(v[1], 50, 100); saveCfg(); sendCfg(); } break;
    case 'T': if (n >= 1) runTimed(v[0] == 0 ? 60 : 0, v[0] == 0 ? 0 : 60, 700, now); break;
    case 'X': invL = invR = swapLR = 0; mode = 1; gainL = gainR = 100; saveCfg(); sendCfg(); break;
    case 'V': BT.println("V,THEP_4WD,v7"); break;
    case 'G': sendCfg(); break;
  }
}

void setup() {
  int pins[] = {IN1, IN2, IN3, IN4};
  for (int i = 0; i < 4; i++) { pinMode(pins[i], OUTPUT); digitalWrite(pins[i], LOW); }
  PWM_ATTACH(ENA, 0); PWM_ATTACH(ENB, 1);
  pref.begin("thep7", false);
  invL = pref.getUChar("il", 0); invR = pref.getUChar("ir", 0); swapLR = pref.getUChar("sw", 0);
  mode = pref.getUChar("md", 1); gainL = pref.getUChar("gl", 100); gainR = pref.getUChar("gr", 100);
  stopNow(false);
  BT.begin("THEP_4WD");
}

void loop() {
  while (BT.available()) {
    char c = BT.read();
    if (c == '\n' || c == '\r') { if (blen) { buf[blen] = 0; handle(buf); blen = 0; } }
    else if (blen < sizeof(buf) - 1) buf[blen++] = c;
  }
  uint32_t now = millis();
  bool moving = tgtL || tgtR || curL || curR;

  if (moving) {
    if (!BT.hasClient()) stopNow(true); // BT หลุด = หยุด
    else if (holdRun) { if (runUntil && (int32_t)(now - runUntil) >= 0) stopNow(true); }
    else if (now - lastCmd > 500) { stopNow(true); if (!fsSent) { BT.println("FS"); fsSent = true; } }
  }

  if (now - lastStep >= 10) {
    lastStep = now;
    const Mode &m = MODES[mode];
    int pl = curL, pr = curR;
    curL += constrain(tgtL - curL, -m.ramp, m.ramp);
    curR += constrain(tgtR - curR, -m.ramp, m.ramp);
    if (m.kickMs) { if (!pl && curL) kickL = now + m.kickMs; if (!pr && curR) kickR = now + m.kickMs; }
    applyOut(now);
  }

  if (now - lastTel >= (uint32_t)MODES[mode].telMs && BT.hasClient()) {
    lastTel = now; BT.printf("T,%d,%d,%d\n", curL, curR, mode);
  }
}
